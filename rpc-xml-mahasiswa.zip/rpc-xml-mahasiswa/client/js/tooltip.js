$(document).ready(function () {
  $("[rel=tooltip]").tooltip();
});
